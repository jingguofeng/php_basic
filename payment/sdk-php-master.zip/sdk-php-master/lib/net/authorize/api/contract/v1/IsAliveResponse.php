<?php

namespace net\authorize\api\contract\v1;

/**
 * Class representing IsAliveResponse
 */
class IsAliveResponse extends ANetApiResponseType
{


}

